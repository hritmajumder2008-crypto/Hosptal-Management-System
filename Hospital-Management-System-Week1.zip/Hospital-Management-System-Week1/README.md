# Hospital Management System — Week 1

A simple academic Hospital Management System built with **C, HTML and CSS**.

## Features

### Patient Management
- Register a new patient
- View all patients
- Search by Patient ID
- Update patient information
- Persistent binary file storage

### Appointment Management
- Book an appointment
- View appointments
- Cancel an appointment
- Persistent binary file storage

### Billing Management
- Create a bill
- Enter consultation charges
- Enter service charges
- Enter medicine charges
- Automatically calculate total
- Display and view bills
- Persistent binary file storage

## Technology Stack

- **C** — backend/business logic
- **HTML5** — frontend structure
- **CSS3** — frontend styling
- **Git/GitHub** — collaboration and version control
- **Binary files** — Week 1 local data storage

## Folder Structure

```text
Hospital-Management-System/
├── backend/
│   ├── main.c
│   ├── patient.c
│   ├── patient.h
│   ├── appointment.c
│   ├── appointment.h
│   ├── billing.c
│   └── billing.h
├── frontend/
│   ├── index.html
│   └── style.css
├── data/
│   ├── patients.dat
│   ├── appointments.dat
│   └── bills.dat
├── .gitignore
└── README.md
```

The `.dat` files are generated automatically after the C program stores its first record.

## How to Compile

Open a terminal inside the `backend` folder.

### GCC

```bash
gcc main.c patient.c appointment.c billing.c -o hospital
```

### Run on Windows

```bash
hospital.exe
```

### Run on Linux/macOS

```bash
./hospital
```

> Run the executable from the `backend` directory so that the relative paths such as `../data/patients.dat` work correctly.

## Frontend

Open:

```text
frontend/index.html
```

in a web browser.

The Week 1 frontend is intentionally a static interface. The C program is the working backend prototype. Connecting browser forms directly to C can be added as a later integration phase.

## Sample Workflow

```text
1. Start the program
2. Select Patient Management
3. Register a patient
4. Note the generated Patient ID
5. Book an appointment using that Patient ID
6. Create a bill for the same Patient ID
7. View/search/update records
8. Exit
```

## Sample Output

```text
============================================
       HOSPITAL MANAGEMENT SYSTEM
              WEEK 1 VERSION
============================================
1. Patient Management
2. Appointment Management
3. Billing Management
4. Exit
--------------------------------------------
Enter your choice: 1

========== PATIENT MANAGEMENT ==========
1. Register New Patient
2. View All Patients
3. Search Patient
4. Update Patient
5. Back to Main Menu
Enter choice: 1

--- Register New Patient ---
Name: Arjun Sen
Age: 21
Gender: Male
Phone: 9876543210
Disease/Reason for Visit: Fever

Patient registered successfully!
Patient ID: 1001
```

Example bill:

```text
============================================
                 PATIENT BILL
============================================
Bill ID          : 8001
Patient ID       : 1001
--------------------------------------------
Consultation     : Rs. 500.00
Service Charges  : Rs. 750.00
Medicine Charges : Rs. 350.00
--------------------------------------------
TOTAL            : Rs. 1600.00
============================================
```

## GitHub Collaboration

Recommended workflow:

```bash
git clone <repository-url>
cd Hospital-Management-System

git checkout -b patient-module
# make changes
git add .
git commit -m "Add patient management module"
git push -u origin patient-module
```

Other branches can be created for:

```text
appointment-module
billing-module
frontend
```

Merge tested branches into `main`.

## Week 1 Scope

This version focuses on:
1. Basic system architecture
2. Modular C programming
3. Structures and functions
4. File handling
5. CRUD-style patient operations
6. Appointment operations
7. Billing calculation
8. Static HTML/CSS frontend
9. GitHub-ready organization

## Future Enhancements

Possible later versions can add:
- Login/authentication
- Doctor management
- Medicine inventory
- Better validation
- Database such as MySQL
- Search by patient name
- Appointment conflict checking
- Responsive form-based frontend
- C/HTML integration through a server/API
- Reports and dashboards

## Academic Note

This is a Week 1 prototype. It is designed to demonstrate the basic modules and architecture without pretending to be a production hospital system. Real hospital software would require stronger security, authentication, audit logs, privacy controls and database infrastructure.
