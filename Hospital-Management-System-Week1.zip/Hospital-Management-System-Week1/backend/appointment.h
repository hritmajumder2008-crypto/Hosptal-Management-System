#ifndef APPOINTMENT_H
#define APPOINTMENT_H

#define APPOINTMENT_FILE "../data/appointments.dat"

typedef struct {
    int appointment_id;
    int patient_id;
    char doctor[50];
    char date[20];
    char time[15];
    int status; /* 1 = Booked, 0 = Cancelled */
} Appointment;

void appointmentMenu(void);
void bookAppointment(void);
void viewAppointments(void);
void cancelAppointment(void);

#endif
