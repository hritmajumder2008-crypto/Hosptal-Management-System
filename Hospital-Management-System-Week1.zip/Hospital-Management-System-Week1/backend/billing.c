#include <stdio.h>
#include "billing.h"

static void clearInput(void) {
    int c;
    while ((c = getchar()) != '\n' && c != EOF) {}
}

static int nextBillId(void) {
    FILE *fp = fopen(BILL_FILE, "rb");
    Bill b;
    int maxId = 8000;

    if (!fp) return maxId + 1;

    while (fread(&b, sizeof(Bill), 1, fp) == 1)
        if (b.bill_id > maxId) maxId = b.bill_id;

    fclose(fp);
    return maxId + 1;
}

static float readCharge(const char *label) {
    float value;

    printf("%s: Rs. ", label);
    while (scanf("%f", &value) != 1 || value < 0) {
        clearInput();
        printf("Enter a valid non-negative amount for %s: Rs. ", label);
    }
    return value;
}

void createBill(void) {
    Bill b;
    FILE *fp;

    b.bill_id = nextBillId();

    printf("\n--- Create Patient Bill ---\n");
    printf("Patient ID: ");

    if (scanf("%d", &b.patient_id) != 1) {
        clearInput();
        printf("Invalid Patient ID.\n");
        return;
    }

    b.consultation = readCharge("Consultation charges");
    b.service = readCharge("Service charges");
    b.medicine = readCharge("Medicine charges");

    b.total = b.consultation + b.service + b.medicine;

    fp = fopen(BILL_FILE, "ab");
    if (!fp) {
        printf("Error: Could not open billing data file.\n");
        return;
    }

    fwrite(&b, sizeof(Bill), 1, fp);
    fclose(fp);

    printf("\nBill created successfully!\n");
    printf("Bill ID: %d\n", b.bill_id);
    printf("Total Amount: Rs. %.2f\n", b.total);
}

void viewBills(void) {
    FILE *fp = fopen(BILL_FILE, "rb");
    Bill b;
    int found = 0;

    printf("\n--- Billing Records ---\n");

    if (!fp) {
        printf("No billing records found.\n");
        return;
    }

    printf("%-8s %-10s %-15s %-15s %-15s %-15s\n",
           "Bill ID", "Patient", "Consultation", "Service", "Medicine", "Total");
    printf("--------------------------------------------------------------------------------\n");

    while (fread(&b, sizeof(Bill), 1, fp) == 1) {
        printf("%-8d %-10d %-15.2f %-15.2f %-15.2f %-15.2f\n",
               b.bill_id, b.patient_id, b.consultation,
               b.service, b.medicine, b.total);
        found = 1;
    }

    fclose(fp);

    if (!found) printf("No billing records found.\n");
}

void displayBill(void) {
    FILE *fp = fopen(BILL_FILE, "rb");
    Bill b;
    int id, found = 0;

    printf("\nEnter Bill ID: ");
    if (scanf("%d", &id) != 1) {
        clearInput();
        printf("Invalid Bill ID.\n");
        return;
    }

    if (!fp) {
        printf("No billing records found.\n");
        return;
    }

    while (fread(&b, sizeof(Bill), 1, fp) == 1) {
        if (b.bill_id == id) {
            printf("\n============================================\n");
            printf("                 PATIENT BILL\n");
            printf("============================================\n");
            printf("Bill ID          : %d\n", b.bill_id);
            printf("Patient ID       : %d\n", b.patient_id);
            printf("--------------------------------------------\n");
            printf("Consultation     : Rs. %.2f\n", b.consultation);
            printf("Service Charges  : Rs. %.2f\n", b.service);
            printf("Medicine Charges : Rs. %.2f\n", b.medicine);
            printf("--------------------------------------------\n");
            printf("TOTAL            : Rs. %.2f\n", b.total);
            printf("============================================\n");
            found = 1;
            break;
        }
    }

    fclose(fp);

    if (!found) printf("Bill with ID %d was not found.\n", id);
}

void billingMenu(void) {
    int choice;

    while (1) {
        printf("\n============ BILLING MANAGEMENT ============\n");
        printf("1. Create Bill\n");
        printf("2. View All Bills\n");
        printf("3. Display Bill\n");
        printf("4. Back to Main Menu\n");
        printf("Enter choice: ");

        if (scanf("%d", &choice) != 1) {
            clearInput();
            printf("Invalid input.\n");
            continue;
        }

        switch (choice) {
            case 1: createBill(); break;
            case 2: viewBills(); break;
            case 3: displayBill(); break;
            case 4: return;
            default: printf("Invalid choice.\n");
        }
    }
}
