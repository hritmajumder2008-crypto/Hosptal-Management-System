#include <stdio.h>
#include <stdlib.h>
#include "patient.h"
#include "appointment.h"
#include "billing.h"

void clearInput(void) {
    int c;
    while ((c = getchar()) != '\n' && c != EOF) {}
}

int main(void) {
    int choice;

    while (1) {
        printf("\n============================================\n");
        printf("       HOSPITAL MANAGEMENT SYSTEM\n");
        printf("              WEEK 1 VERSION\n");
        printf("============================================\n");
        printf("1. Patient Management\n");
        printf("2. Appointment Management\n");
        printf("3. Billing Management\n");
        printf("4. Exit\n");
        printf("--------------------------------------------\n");
        printf("Enter your choice: ");

        if (scanf("%d", &choice) != 1) {
            clearInput();
            printf("Invalid input. Please enter a number.\n");
            continue;
        }

        switch (choice) {
            case 1: patientMenu(); break;
            case 2: appointmentMenu(); break;
            case 3: billingMenu(); break;
            case 4:
                printf("\nThank you for using the Hospital Management System.\n");
                return 0;
            default:
                printf("Invalid choice. Please try again.\n");
        }
    }
}
