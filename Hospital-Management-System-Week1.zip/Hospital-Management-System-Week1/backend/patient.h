#ifndef PATIENT_H
#define PATIENT_H

#define PATIENT_FILE "../data/patients.dat"

typedef struct {
    int patient_id;
    char name[50];
    int age;
    char gender[15];
    char phone[20];
    char disease[100];
} Patient;

void patientMenu(void);
void registerPatient(void);
void viewPatients(void);
void searchPatient(void);
void updatePatient(void);

#endif
