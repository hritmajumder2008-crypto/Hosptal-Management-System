#ifndef BILLING_H
#define BILLING_H

#define BILL_FILE "../data/bills.dat"

typedef struct {
    int bill_id;
    int patient_id;
    float consultation;
    float service;
    float medicine;
    float total;
} Bill;

void billingMenu(void);
void createBill(void);
void viewBills(void);
void displayBill(void);

#endif
