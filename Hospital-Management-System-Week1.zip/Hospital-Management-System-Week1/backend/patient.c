#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "patient.h"

static void readLine(char *buffer, int size) {
    if (fgets(buffer, size, stdin)) {
        buffer[strcspn(buffer, "\n")] = '\0';
    }
}

static void clearInput(void) {
    int c;
    while ((c = getchar()) != '\n' && c != EOF) {}
}

static int nextPatientId(void) {
    FILE *fp = fopen(PATIENT_FILE, "rb");
    Patient p;
    int maxId = 1000;

    if (!fp) return maxId + 1;

    while (fread(&p, sizeof(Patient), 1, fp) == 1) {
        if (p.patient_id > maxId) maxId = p.patient_id;
    }
    fclose(fp);
    return maxId + 1;
}

void registerPatient(void) {
    Patient p;
    FILE *fp;

    p.patient_id = nextPatientId();

    clearInput();
    printf("\n--- Register New Patient ---\n");
    printf("Name: ");
    readLine(p.name, sizeof(p.name));

    printf("Age: ");
    while (scanf("%d", &p.age) != 1 || p.age < 0 || p.age > 130) {
        clearInput();
        printf("Enter a valid age: ");
    }

    clearInput();
    printf("Gender: ");
    readLine(p.gender, sizeof(p.gender));

    printf("Phone: ");
    readLine(p.phone, sizeof(p.phone));

    printf("Disease/Reason for Visit: ");
    readLine(p.disease, sizeof(p.disease));

    fp = fopen(PATIENT_FILE, "ab");
    if (!fp) {
        printf("Error: Could not open patient data file.\n");
        return;
    }

    fwrite(&p, sizeof(Patient), 1, fp);
    fclose(fp);

    printf("\nPatient registered successfully!\n");
    printf("Patient ID: %d\n", p.patient_id);
}

void viewPatients(void) {
    FILE *fp = fopen(PATIENT_FILE, "rb");
    Patient p;
    int found = 0;

    printf("\n--- Patient Records ---\n");

    if (!fp) {
        printf("No patient records found.\n");
        return;
    }

    printf("%-6s %-22s %-5s %-10s %-16s %-25s\n",
           "ID", "Name", "Age", "Gender", "Phone", "Disease");
    printf("--------------------------------------------------------------------------------\n");

    while (fread(&p, sizeof(Patient), 1, fp) == 1) {
        printf("%-6d %-22s %-5d %-10s %-16s %-25s\n",
               p.patient_id, p.name, p.age, p.gender, p.phone, p.disease);
        found = 1;
    }

    fclose(fp);

    if (!found) printf("No patient records found.\n");
}

void searchPatient(void) {
    FILE *fp = fopen(PATIENT_FILE, "rb");
    Patient p;
    int id, found = 0;

    printf("\nEnter Patient ID to search: ");
    if (scanf("%d", &id) != 1) {
        clearInput();
        printf("Invalid Patient ID.\n");
        return;
    }

    if (!fp) {
        printf("No patient records found.\n");
        return;
    }

    while (fread(&p, sizeof(Patient), 1, fp) == 1) {
        if (p.patient_id == id) {
            printf("\nPatient Found\n");
            printf("ID       : %d\n", p.patient_id);
            printf("Name     : %s\n", p.name);
            printf("Age      : %d\n", p.age);
            printf("Gender   : %s\n", p.gender);
            printf("Phone    : %s\n", p.phone);
            printf("Disease  : %s\n", p.disease);
            found = 1;
            break;
        }
    }

    fclose(fp);

    if (!found) printf("Patient with ID %d was not found.\n", id);
}

void updatePatient(void) {
    FILE *fp = fopen(PATIENT_FILE, "rb+");
    Patient p;
    int id, found = 0;

    printf("\nEnter Patient ID to update: ");
    if (scanf("%d", &id) != 1) {
        clearInput();
        printf("Invalid Patient ID.\n");
        return;
    }

    if (!fp) {
        printf("No patient records found.\n");
        return;
    }

    while (fread(&p, sizeof(Patient), 1, fp) == 1) {
        if (p.patient_id == id) {
            clearInput();

            printf("New name: ");
            readLine(p.name, sizeof(p.name));

            printf("New age: ");
            while (scanf("%d", &p.age) != 1 || p.age < 0 || p.age > 130) {
                clearInput();
                printf("Enter a valid age: ");
            }

            clearInput();
            printf("New gender: ");
            readLine(p.gender, sizeof(p.gender));

            printf("New phone: ");
            readLine(p.phone, sizeof(p.phone));

            printf("New disease/reason: ");
            readLine(p.disease, sizeof(p.disease));

            fseek(fp, -(long)sizeof(Patient), SEEK_CUR);
            fwrite(&p, sizeof(Patient), 1, fp);
            found = 1;
            printf("\nPatient information updated successfully.\n");
            break;
        }
    }

    fclose(fp);

    if (!found) printf("Patient with ID %d was not found.\n", id);
}

void patientMenu(void) {
    int choice;

    while (1) {
        printf("\n========== PATIENT MANAGEMENT ==========\n");
        printf("1. Register New Patient\n");
        printf("2. View All Patients\n");
        printf("3. Search Patient\n");
        printf("4. Update Patient\n");
        printf("5. Back to Main Menu\n");
        printf("Enter choice: ");

        if (scanf("%d", &choice) != 1) {
            clearInput();
            printf("Invalid input.\n");
            continue;
        }

        switch (choice) {
            case 1: registerPatient(); break;
            case 2: viewPatients(); break;
            case 3: searchPatient(); break;
            case 4: updatePatient(); break;
            case 5: return;
            default: printf("Invalid choice.\n");
        }
    }
}
