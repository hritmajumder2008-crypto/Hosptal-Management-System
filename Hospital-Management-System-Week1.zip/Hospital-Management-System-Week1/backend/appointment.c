#include <stdio.h>
#include <string.h>
#include "appointment.h"

static void readLine(char *buffer, int size) {
    if (fgets(buffer, size, stdin))
        buffer[strcspn(buffer, "\n")] = '\0';
}

static void clearInput(void) {
    int c;
    while ((c = getchar()) != '\n' && c != EOF) {}
}

static int nextAppointmentId(void) {
    FILE *fp = fopen(APPOINTMENT_FILE, "rb");
    Appointment a;
    int maxId = 5000;

    if (!fp) return maxId + 1;

    while (fread(&a, sizeof(Appointment), 1, fp) == 1)
        if (a.appointment_id > maxId) maxId = a.appointment_id;

    fclose(fp);
    return maxId + 1;
}

void bookAppointment(void) {
    Appointment a;
    FILE *fp;

    a.appointment_id = nextAppointmentId();
    a.status = 1;

    printf("\n--- Book Appointment ---\n");
    printf("Patient ID: ");
    if (scanf("%d", &a.patient_id) != 1) {
        clearInput();
        printf("Invalid Patient ID.\n");
        return;
    }

    clearInput();
    printf("Doctor name: ");
    readLine(a.doctor, sizeof(a.doctor));

    printf("Date (DD-MM-YYYY): ");
    readLine(a.date, sizeof(a.date));

    printf("Time (e.g. 10:30 AM): ");
    readLine(a.time, sizeof(a.time));

    fp = fopen(APPOINTMENT_FILE, "ab");
    if (!fp) {
        printf("Error: Could not open appointment data file.\n");
        return;
    }

    fwrite(&a, sizeof(Appointment), 1, fp);
    fclose(fp);

    printf("\nAppointment booked successfully!\n");
    printf("Appointment ID: %d\n", a.appointment_id);
}

void viewAppointments(void) {
    FILE *fp = fopen(APPOINTMENT_FILE, "rb");
    Appointment a;
    int found = 0;

    printf("\n--- Appointment Records ---\n");

    if (!fp) {
        printf("No appointments found.\n");
        return;
    }

    printf("%-8s %-10s %-22s %-15s %-12s %-12s\n",
           "App.ID", "Patient", "Doctor", "Date", "Time", "Status");
    printf("----------------------------------------------------------------------------\n");

    while (fread(&a, sizeof(Appointment), 1, fp) == 1) {
        printf("%-8d %-10d %-22s %-15s %-12s %-12s\n",
               a.appointment_id, a.patient_id, a.doctor, a.date,
               a.time, a.status ? "Booked" : "Cancelled");
        found = 1;
    }

    fclose(fp);

    if (!found) printf("No appointments found.\n");
}

void cancelAppointment(void) {
    FILE *fp = fopen(APPOINTMENT_FILE, "rb+");
    Appointment a;
    int id, found = 0;

    printf("\nEnter Appointment ID to cancel: ");
    if (scanf("%d", &id) != 1) {
        clearInput();
        printf("Invalid Appointment ID.\n");
        return;
    }

    if (!fp) {
        printf("No appointments found.\n");
        return;
    }

    while (fread(&a, sizeof(Appointment), 1, fp) == 1) {
        if (a.appointment_id == id) {
            a.status = 0;
            fseek(fp, -(long)sizeof(Appointment), SEEK_CUR);
            fwrite(&a, sizeof(Appointment), 1, fp);
            found = 1;
            printf("Appointment %d cancelled successfully.\n", id);
            break;
        }
    }

    fclose(fp);

    if (!found) printf("Appointment with ID %d was not found.\n", id);
}

void appointmentMenu(void) {
    int choice;

    while (1) {
        printf("\n======== APPOINTMENT MANAGEMENT ========\n");
        printf("1. Book Appointment\n");
        printf("2. View Appointments\n");
        printf("3. Cancel Appointment\n");
        printf("4. Back to Main Menu\n");
        printf("Enter choice: ");

        if (scanf("%d", &choice) != 1) {
            clearInput();
            printf("Invalid input.\n");
            continue;
        }

        switch (choice) {
            case 1: bookAppointment(); break;
            case 2: viewAppointments(); break;
            case 3: cancelAppointment(); break;
            case 4: return;
            default: printf("Invalid choice.\n");
        }
    }
}
